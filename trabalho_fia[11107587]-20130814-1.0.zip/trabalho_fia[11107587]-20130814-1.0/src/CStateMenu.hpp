/*
 * CStateMenu.hpp
 *
 *  Created on: 01/07/2013
 *      Author: andref
 */

#ifndef CSTATEMENU_HPP_
#define CSTATEMENU_HPP_

#include <SFML/Graphics.hpp>
#include "CState.hpp"
#include "CEntity.hpp"
#include "CTileMap.hpp"

class CStateMenu : public CState {
private:
	static CStateMenu instance;
private:
	CStateMenu();

	sf::Font font;
	CText menuText;
	CButton jogoBMenu;
	CButton exitBMenu;

public:
	void OnActivation();
	void OnDeactivation();
	void OnLoop();
	void OnRender(sf::RenderWindow * window);

public:
	static CStateMenu * GetIntance();

	void KeyPressed(sf::Event::KeyEvent keyEvent);
	void MouseMoved(sf::Event::MouseMoveEvent mouseMoveEvent);
	void MouseButtonPressed(sf::Event::MouseButtonEvent mouseButtonEvent);
	void MouseButtonReleased(sf::Event::MouseButtonEvent mouseButtonEvent);
};

#endif /* CSTATEMENU_HPP_ */

