/*
 * CStateMenu.cpp
 *
 *  Created on: 01/07/2013
 *      Author: andref
 */

#include "CStateMenu.hpp"
#include "CStateManager.hpp"
#include <iostream>

CStateMenu CStateMenu::instance;

CStateMenu::CStateMenu() {
}

void CStateMenu::OnActivation() {
	try {
		std::string fontName = "fonts/Serious-2.ttf";
		if (!this->font.loadFromFile(fontName))
			throw;
		this->menuText.setPosition(10,10);
		this->menuText.load("Teste A*",this->font,40);
		this->jogoBMenu.setPosition(this->menuText.getPosition().x + 30, this->menuText.getPosition().y + 40);
		this->jogoBMenu.load("Iniciar Jogo*",this->font,40);
		this->jogoBMenu.SetColor(sf::Color::Black);
		this->jogoBMenu.SetBackground(sf::Color::White);

		this->exitBMenu.setPosition(this->jogoBMenu.getPosition().x, this->jogoBMenu.getPosition().y + 40);
		this->exitBMenu.load("Sair",this->font,40);
		this->exitBMenu.SetColor(sf::Color::Black);
		this->exitBMenu.SetBackground(sf::Color::White);

	} catch(int e) {
		std::cout << "Deu erro D:" << std::endl;
	}
}

void CStateMenu::OnDeactivation() {
	this->menuText.Unload();
	this->jogoBMenu.Unload();
	this->exitBMenu.Unload();

//	this->jogoBMenu.~Drawable();
}

void CStateMenu::OnLoop() {

}

void CStateMenu::OnRender(sf::RenderWindow * window) {

	//for (int i = 0; i < entityList.size(); i++) {
		//window->draw(entiyList[i]->OnDraw();
	//}
	window->draw(this->menuText);
	window->draw(this->jogoBMenu);
	window->draw(this->exitBMenu);

	window->display();
	window->clear(sf::Color::Black);
}

CStateMenu * CStateMenu::GetIntance() {
	return & instance;
}
void CStateMenu::MouseMoved(sf::Event::MouseMoveEvent mouseMoveEvent) {
	this->jogoBMenu.Highlight(sf::Vector2f(mouseMoveEvent.x,mouseMoveEvent.y));
	this->exitBMenu.Highlight(sf::Vector2f(mouseMoveEvent.x,mouseMoveEvent.y));
}
void CStateMenu::MouseButtonPressed(sf::Event::MouseButtonEvent mouseButtonEvent) {
	if (this->jogoBMenu.OnHover(sf::Vector2f(mouseButtonEvent.x,mouseButtonEvent.y)))
		CStateManager::SetActiveState(STATE_GAME);
	if (this->exitBMenu.OnHover(sf::Vector2f(mouseButtonEvent.x,mouseButtonEvent.y)))
		CStateManager::SetActiveState(STATE_NONE);
}
void CStateMenu::MouseButtonReleased(sf::Event::MouseButtonEvent mouseButtonEvent) {
}
void CStateMenu::KeyPressed(sf::Event::KeyEvent keyEvent) {
	if (keyEvent.code == sf::Keyboard::Escape)
		CStateManager::SetActiveState(STATE_NONE);
	if (keyEvent.code == sf::Keyboard::Space)
		CStateManager::SetActiveState(STATE_GAME);
}
