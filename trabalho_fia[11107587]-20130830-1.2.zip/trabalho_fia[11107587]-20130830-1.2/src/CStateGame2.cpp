/*
 * CStateGame2.cpp
 *
 *  Created on: 20/08/2013
 *      Author: andref
 */

#include "CStateGame2.hpp"
#include "CStateManager.hpp"

#include "CBoardMap.hpp"

CStateGame2 CStateGame2::instance;

void CStateGame2::OnActivation() {
	try {
		this->leftClick = false;
		this->rightClick = false;
		this->middleClick = false;
		CBoardMap::board = CBoardMap();

		CBoardMap::board.NewGame();

		CBoardMap::board.player = PLAYER_1;
		sf::Vector2f boardSize(800,560);
		sf::Vector2i boardTile(10,7);
		CBoardMap::board.Structure(boardSize,boardTile);
		float halfWidth = 1150 / 2;
		float halfHeight = 640 - (boardSize.y / 2);
		CBoardMap::board.setPosition(halfWidth - boardSize.x / 2 ,halfHeight - boardSize.y / 2);


	} catch (int e) {
		return;
	}
}

void CStateGame2::OnDeactivation() {
	for (unsigned int i = 0; i < CEntity::entityList.size(); i++) {
		if (!CEntity::entityList[i])
			continue;
		CEntity::entityList[i]->Unload();
	}
	CEntity::entityList.clear();
}

void CStateGame2::OnLoop() {
	if (this->mousePos != sf::Vector2i(-1,-1)) {
		CBoardMap::board.ColorBoard();
		//CBoardMap::board.HighlightRow(this->mousePos);
		if (CBoardMap::board.playerWinner == NO_PLAYER) {
			if (this->leftClick) {
				this->leftClick = false;
				if (CBoardMap::board.player == PLAYER_1) {
					CBoardMap::board.PlayerTurn(this->mousePos.x);
				} else {
					std::cout << "Espere seu turno" << std::endl;
				}
			}
			if (this->rightClick) {
				this->rightClick = false;
				if (CBoardMap::board.player == PLAYER_2) {
					//CBoardMap::board.IATurn(CBoardMap::board.player);
					CBoardMap::board.PlayerTurn(this->mousePos.x);
				} else {
					std::cout << "Espere seu turno" << std::endl;
				}
			}
			if (this->middleClick) {
				this->middleClick = false;
				if (CBoardMap::board.player == PLAYER_2) {
					CBoardMap::board.IATurn(CBoardMap::board.player);
				} else {
					std::cout << "Espere seu turno" << std::endl;
				}
			}
		} else {
			if (this->leftClick || this->rightClick || this->middleClick) {
				this->rightClick = this->leftClick = this->middleClick = false;
				std::cout << "Partida Finalizada! Jogador " << CBoardMap::board.playerWinner << " foi o vencedor." << std::endl;
			}

		}
		//std::cout << "this->mousePos: " << this->mousePos.x << " " << this->mousePos.y << std::endl;
	}
	for (unsigned int i = 0; i < CEntity::entityList.size(); i++) {
		if (!CEntity::entityList[i])
			continue;
		CEntity::entityList[i]->OnLoop();
	}
}

void CStateGame2::OnRender(sf::RenderWindow * window) {

	window->draw(CBoardMap::board);
	for (unsigned int i = 0; i < CEntity::entityList.size(); i++) {
		window->draw(*CEntity::entityList[i]);
	}
	window->display();
	window->clear(sf::Color::Black);
}

CStateGame2 * CStateGame2::GetIntance() {
	return & instance;
}
void CStateGame2::MouseMoved(sf::Event::MouseMoveEvent mouseMoveEvent) {
	sf::Vector2f mouseCords(mouseMoveEvent.x,mouseMoveEvent.y);
	this->mousePos = sf::Vector2i(CBoardMap::board.MapToPos(mouseCords));
}
void CStateGame2::MouseButtonPressed(sf::Event::MouseButtonEvent mouseButtonEvent) {
	if ( mouseButtonEvent.button == sf::Mouse::Left ) {
		this->leftClick = true;
	}
	if ( mouseButtonEvent.button == sf::Mouse::Right ) {
		this->rightClick = true;
	}
	if ( mouseButtonEvent.button == sf::Mouse::Middle ) {
		this->middleClick = true;
	}
}
void CStateGame2::MouseButtonReleased(sf::Event::MouseButtonEvent mouseButtonEvent) {
	if ( mouseButtonEvent.button == sf::Mouse::Left ) {
		this->leftClick = false;
	}
	if ( mouseButtonEvent.button == sf::Mouse::Right ) {
		this->rightClick = false;
	}
	if ( mouseButtonEvent.button == sf::Mouse::Middle ) {
		this->middleClick = false;
	}
}
void CStateGame2::KeyPressed(sf::Event::KeyEvent keyEvent) {
	if (keyEvent.code == sf::Keyboard::Escape)
		CStateManager::SetActiveState(STATE_MENU);
	//CStateManager::SetActiveState(STATE_NONE);

}
