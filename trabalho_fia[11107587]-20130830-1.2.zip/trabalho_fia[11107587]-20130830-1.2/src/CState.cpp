/*
 * CState.cpp
 *
 *  Created on: 19/06/2013
 *      Author: andref
 */

#include "CState.hpp"

CState::CState() {
}

void CState::OnActivation() {
}
void CState::OnDeactivation() {
}
void CState::OnLoop() {
}
void CState::OnRender(sf::RenderWindow * window) {
}
